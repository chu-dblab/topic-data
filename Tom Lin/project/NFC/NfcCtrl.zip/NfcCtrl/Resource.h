//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NfcCtrl.rc
//
#define IDS_PROJNAME                    100
#define IDR_NFCCTRL                     101
#define IDR_MIFARE                      102
#define IDD_SELECT                      201
#define IDC_LIST                        202

#define IDB_WAVE_1                      301
#define IDB_WAVE_2                      302
#define IDB_WAVE_3                      303
#define IDB_WAVE_4                      304

#define IDB_ETC_1                       401
#define IDB_ETC_2                       402
#define IDB_ETC_3                       403
#define IDB_ETC_4                       404

#define ERR_READER_NOT_FOUND		1000
#define ERR_CANCEL_PAYMENT			1001
#define ERR_BALANCE_NOT_ENOUGH		1002
#define ERR_RF_TOO_FAR				1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
